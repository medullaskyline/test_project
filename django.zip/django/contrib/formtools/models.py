# This file is required to pretend formtools has models.
# Otherwise test models cannot be registered.

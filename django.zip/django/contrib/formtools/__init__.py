default_app_config = 'django.contrib.formtools.apps.FormToolsConfig'
